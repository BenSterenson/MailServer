/*
 * MSG_Login.cpp
 *
 *  Created on: Nov 21, 2016
 *      Author: bensterenson
 */

#include "Server_MSG_Login.h"

MSG_Login::MSG_Login(CMessage* msg) {
	// TODO
}

MSG_Login::~MSG_Login() {

}
