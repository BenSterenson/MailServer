/*
 * Message.c
 *
 *  Created on: Nov 21, 2016
 *      Author: bensterenson
 */

#include <string>
#include "Message.h"
#include "General.h"

using std::string;

CReply::CReply() {
	this->length = 0;
}

CReply::~CReply() {

}

void CReply::ParseMsg() {
}
